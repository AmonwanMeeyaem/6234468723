/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_3;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 *
 * @author Administrater
 */
public class Gregorian_Calendar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    GregorianCalendar today = new GregorianCalendar (2020,Calendar.JANUARY,20);
    GregorianCalendar myBirthday = new GregorianCalendar (2001,Calendar.FEBRUARY,14);
    today.add(Calendar.DAY_OF_MONTH, 100);
    myBirthday.add(Calendar.DAY_OF_MONTH,10000);
    int dayOfMonth = today.get(Calendar.DAY_OF_MONTH);
    int month = today.get(Calendar.MONTH)+1;
    int year = today.get(Calendar.YEAR);
    int weekday = today.get(Calendar.DAY_OF_WEEK);
    int dayOfMonth2 = myBirthday.get(Calendar.DAY_OF_MONTH);
    int month2 = myBirthday.get(Calendar.MONTH)+1;
    int year2 = myBirthday.get(Calendar.YEAR);
    int weekday2 = myBirthday.get(Calendar.DAY_OF_WEEK);
    System.out.printf("%d%d%d%d",weekday,dayOfMonth,month,year);
    System.out.printf("\n%d%d%d%d",weekday2,dayOfMonth2,month2,year2);
    
    }
    
}
