package com.example.lab6_4;
import java.lang.Math;
public class Game {
    private int num;
    public Game(){
        num = (int) Math.floor(Math.random()*Math.floor(100))+1;
    }
    public String Guess(int guess){
        String check;
        if(guess>num){
            check="Your guess is too high";
        }else if(guess<num){
            check="Your guess is too low";
        }else {
            check="You won";
        }
        return check;
    }
}
