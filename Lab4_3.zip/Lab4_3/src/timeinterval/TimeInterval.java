package timeinterval;
import java.lang.Math;
public class TimeInterval {
    private int startTime,endTime = 0;
    private int startHr,startMin,endHr,endMin = 0;
    private int start,end = 0;
    public TimeInterval(int ST, int ET){
        startTime = ST;
        endTime = ET;
        
        startHr = ST/100;
        startMin = ST%100;
        endHr = ET/100;
        endMin = ET%100;
                
        end = endMin + (endHr*60);
        start = startMin + (startHr*60);
    }
    
    public int getHours(){
        return((int) ((end-start)/60));
    }

    public int getMinutes(){
        return((end-start)%60);      
    }
}
