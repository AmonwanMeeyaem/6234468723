/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_2;

/**
 *
 * @author Acer
 */
public class Question {
    private String text;
    private String answer;
    
    public Question(){
        
    }
    public Question(String text){
        this.text = text;
    }
    
    public void setText(String t){
        text = t;
    }
    public void setAnswer(String s){
        answer = s;
    }
    public String getText(){
        return text;
    }
    public String getAnswer(){
        return answer;
    }
    
    public boolean checkAnswer(String response){
        return response.equalsIgnoreCase(answer);
    }
    public void display(){
        System.out.println(text);
    }
}
   
