/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_1;

/**
 *
 * @author Acer
 */
public class Truck extends Car{
    private double M_weight;
    private double weight;
    
    public Truck(double gas,double efficiency,double M_weight,double weight){
        super(gas,efficiency);
        this.M_weight = M_weight;
        this.weight = weight;
        if(M_weight<weight){
            this.weight = M_weight;
        }else{
            this.weight = weight;}
    }
    
    @Override
    public void drive(double distance){
        double g = super.getGas();
        double d = distance/super.getEfficiency();
        double f = 1.0;
        if(weight<1)
            f = 1.0;
        else if(weight<=10)
            f = 1.1;
        else if(weight<=20)
            f = 1.2;
        else if(weight>20)
            f = 1.3;
        
        if((g-d*f) < 0){
            System.out.println("You cannot drive too far, please add gas.");
        }else{
            super.setGas(g-d*f);
        }
        
    }
}
