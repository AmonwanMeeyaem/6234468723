/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_1;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 *
 * @author 
 */
public class Order {

    public static int cntOrder = 0; //จน order
    private int id; //order ที่เท่าไหร่
    private Customer c;
    private ArrayList<Pizza> p;
    
    public Order (Customer c){
        this.c = c;
        this.p = new ArrayList<Pizza>();
    }
            
    public void addPizza (Pizza pizza){
        p.add(pizza);
    }

    public String getOrderDetail(){
        cntOrder++;
        this.id = cntOrder;
        String order = "Order id : "+this.id+"\n"+c.toString()+"\n";
        for(Pizza pizza:this.p){
            order+=pizza.toString()+"\n";

        }
        order+="Total pieces : "+p.size()+"\n"+"Total cost : "+calculatePayment();
        return order;
    }
    public double calculatePayment(){
        double total=0;
        for(Pizza pizza:this.p){
            total = total+pizza.getPrice();
        }
        if (c instanceof GoldCustomer){
            GoldCustomer gc = (GoldCustomer) c;
            return total-(total*(gc.getDiscount()/100));
        }
        else
            return total;
    }
    
}
