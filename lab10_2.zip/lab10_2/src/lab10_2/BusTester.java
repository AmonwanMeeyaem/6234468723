/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_2;

import java.util.ArrayList;

/**
 *
 * @author 
 */
public class BusTester {
    public static void main(String[] args) {
        ArrayList<Bus> arr = new ArrayList<Bus>();
        arr.add(new Hybrid(45,1200000,600,150,1));
        arr.add(new CNGBus(50,1000000,200,2));
        for (Bus b : arr){
            System.out.println("ID: "+b.getID());
            if(b instanceof Hybrid){
                Hybrid hy = (Hybrid) b;
                //System.out.println("Emission Tier: "+hy.getEmissionTier()+"\nAccel: "+hy.getAccel());
                System.out.println("Emission Tier: "+hy.getEmissionTier()+"\nAccel: "+hy.getAccel());
            }
            if(b instanceof CNGBus){
                CNGBus cng = (CNGBus) b;
                System.out.println("Emission Tier: "+cng.getEmissionTier()+"\nAccel: "+cng.getAccel());
            }
        }
    }
}
