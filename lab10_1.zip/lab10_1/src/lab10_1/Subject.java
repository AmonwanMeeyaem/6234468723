/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_1;

/**
 *
 * @author 
 */
public class Subject implements Evaluation{
    private String subjName;
    private int score[];
    private double average;
    private char grade;
    
    public Subject(String subjName,int score[]){
        this.subjName = subjName;
        this.score = score;
    }
    
    @Override
    public double evaluate(){
        int total = 0;
        for (int i=0;i<score.length;i++){
            total = total+score[i];
        }
        average = total/score.length;
        return average;
    }
    @Override
    public char grade(double average){
        if (average>=70){
            grade = 'P';
        }
        else{
            grade = 'F' ;
        }
        return grade;
    }
    @Override
    public String toString(){
        return subjName;
    }
    
}
