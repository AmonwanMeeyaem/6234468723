/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_2;

/**
 *
 * @author usci
 */
public class helloPrinter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String s1="Hello, World!";  
        String replaceString=s1.replace("o","x").replace("e","O").replace("x","e");
        
        System.out.println(replaceString);
    }
    
}
